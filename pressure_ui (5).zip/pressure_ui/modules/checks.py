"""
Checklist / loader page -- shown briefly between the home page and the
normal multi-page app. Verifies every path a section depends on actually
resolves to a real file, ticking each one in place, and fails loudly with
one clear message (rather than letting five different sections each show
their own confusing partial error) if a REQUIRED file is missing.
"""

import os
import time

import streamlit as st

from modules import pipeline_paths

# (label, paths.py attribute, required-to-open-the-app)
CHECK_ITEMS = [
    ("Detection & tracking cache — player", "PLAYER_FRAME_TABLE_CACHE_PATH", True),
    ("Detection & tracking cache — ball", "BALL_FRAME_TABLE_CACHE_PATH", True),
    ("Pressure metrics export", "UI_EXPORT_PATH", True),
    ("LLM tactical report", "LLM_REPORT_PATH", False),
    ("Rendered output video", "OUTPUT_VIDEO_PATH", False),
]

STEP_DELAY_SEC = 0.35  # purely cosmetic pacing so each tick is readable, not a real wait


def _resolve_from_pipeline(root: str) -> list[dict]:
    results = []
    for label, attr, required in CHECK_ITEMS:
        path = pipeline_paths.get(attr, None, extra_root=root)
        results.append({"label": label, "attr": attr, "path": path, "required": required,
                         "exists": bool(path) and os.path.exists(path)})
    return results


def _resolve_from_upload() -> list[dict]:
    # uploaded mode has no detection/tracking caches of its own -- those two checks are
    # skipped entirely rather than shown as failing, since they're not applicable here
    uploaded = st.session_state.get("uploaded_paths", {})
    results = []
    for label, attr, required in CHECK_ITEMS:
        if attr not in uploaded:
            continue
        path = uploaded.get(attr)
        results.append({"label": label, "attr": attr, "path": path, "required": required,
                         "exists": bool(path) and os.path.exists(path)})
    return results


def render() -> None:
    st.markdown(
        """
        <div class="hero-wrap" style="padding-top:56px; padding-bottom:8px;">
            <div class="hero-badge">⚽</div>
            <div class="hero-title" style="font-size:1.5rem;">Checking pipeline outputs…</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    _, center, _ = st.columns([1, 2, 1])
    with center:
        if st.session_state.get("input_mode") == "upload":
            items = _resolve_from_upload()
        else:
            items = _resolve_from_pipeline(st.session_state.get("pipeline_root", pipeline_paths.PIPELINE_ROOT))

        # render every row as "pending" first, then tick them one at a time in place --
        # each placeholder streams to the browser as soon as it's written, so the
        # time.sleep() calls below produce a real sequential-tick effect in one script run
        placeholders = {}
        for item in items:
            placeholders[item["attr"]] = st.empty()
            placeholders[item["attr"]].markdown(
                f'<div class="check-row pending"><span class="icon">⏳</span>'
                f'<span class="label">{item["label"]}</span></div>',
                unsafe_allow_html=True,
            )

        missing_required = []
        resolved_paths = {}
        for item in items:
            time.sleep(STEP_DELAY_SEC)
            resolved_paths[item["attr"]] = item["path"]
            if item["exists"]:
                icon, css = "✅", "ok"
            elif item["required"]:
                icon, css = "❌", "fail"
                missing_required.append(item)
            else:
                icon, css = "⚠️", "warn"
            path_label = item["path"] or "not set in paths.py"
            placeholders[item["attr"]].markdown(
                f'<div class="check-row {css}"><span class="icon">{icon}</span>'
                f'<span class="label">{item["label"]}</span>'
                f'<span class="path">{path_label}</span></div>',
                unsafe_allow_html=True,
            )

        time.sleep(STEP_DELAY_SEC * 1.5)  # brief pause so the last tick is readable before we move on

        st.session_state.resolved_paths = resolved_paths
        if missing_required:
            st.session_state.missing_required = missing_required
            st.session_state.app_stage = "error"
        else:
            st.session_state.data_path = resolved_paths.get("UI_EXPORT_PATH")
            st.session_state.app_stage = "ready"
        st.rerun()


def render_error() -> None:
    st.markdown(
        """
        <div class="hero-wrap" style="padding-top:56px; padding-bottom:8px;">
            <div class="hero-badge">⚠️</div>
            <div class="hero-title" style="font-size:1.5rem;">Pipeline output not found</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    _, center, _ = st.columns([1, 2, 1])
    with center:
        st.error(
            "**Please run `main.py` — the pipeline cache doesn't exist yet.**\n\n"
            "The following required file(s) weren't found. Run the pipeline (or the notebook "
            "section that writes them) first, then come back and try again."
        )
        for item in st.session_state.get("missing_required", []):
            st.markdown(
                f'<div class="check-row fail"><span class="icon">❌</span>'
                f'<span class="label">{item["label"]}</span>'
                f'<span class="path">{item["path"] or "not set in paths.py"}</span></div>',
                unsafe_allow_html=True,
            )

        st.write("")
        if st.button("← Back", width="stretch"):
            st.session_state.app_stage = "home"
            st.rerun()
